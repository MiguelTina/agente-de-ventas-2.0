require('dotenv').config();
const express = require('express');
const { OpenAI } = require('openai');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extend: true }));

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

app.post('/whatsapp', async (req, res) => {
  const pregunta = req.body.mensaje;

  try {
    const respuesta = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: 'Eres un asistente legal que responde con precisión y profesionalismo sobre temas legales en México. No inventes datos. Responde solo si estás seguro.',
        },
        {
          role: 'user',
          content: pregunta,
        },
      ],
    });

    res.json({ respuesta: respuesta.choices[0].message.content });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error al generar respuesta');
  }
});

app.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});
