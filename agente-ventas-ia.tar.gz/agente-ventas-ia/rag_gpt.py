from langchain.agents import initialize_agent, Tool
from langchain.llms import OpenAI
import requests

# Herramientas (tus endpoints)
def buscar_productos(nombre):
    res = requests.get(f"http://localhost:8000/buscar?nombre={nombre}")
    return res.json()

def agregar_al_carrito(nombre):
    res = requests.post("http://localhost:8000/agregar-al-carrito", json={"nombre": nombre})
    return res.json()

tools = [
    Tool(name="BuscarProducto", func=buscar_productos, description="Busca productos por nombre"),
    Tool(name="AgregarAlCarrito", func=agregar_al_carrito, description="Agrega productos al carrito")
]

llm = OpenAI(temperature=0)

agent = initialize_agent(tools, llm, agent="zero-shot-react-description", verbose=True)

respuesta = agent.run("Quiero 2 botes de pintura vinílica color blanco")
print(respuesta)